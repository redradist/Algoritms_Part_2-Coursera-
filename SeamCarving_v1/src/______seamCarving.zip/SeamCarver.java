
import edu.princeton.cs.algs4.EdgeWeightedDigraph;
import edu.princeton.cs.algs4.DijkstraSP;
import edu.princeton.cs.algs4.DirectedEdge;
import edu.princeton.cs.algs4.Picture;
import java.awt.Color;
import java.util.Iterator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author REDRADIST
 */
public class SeamCarver {
   private Picture mPicture;
   private final double[][] mEnergy;
   public SeamCarver(Picture picture)
   {
    mPicture = new Picture(picture);
    mEnergy = new double[mPicture.width()][mPicture.height()];
    int size_x = mPicture.width(); 
    int size_y = mPicture.height();
    for (int x = 0; x < size_x; ++x)
    {
        for (int y = 0; y < size_y; ++y) 
        {
           mEnergy[x][y] = energy(x, y);
        }
    }
   }
   
   public Picture picture()
   {
       return mPicture;
   }
   
   public int width()
   {
       return mPicture.width();
   }
   public int height()
   {
       return mPicture.height();
   }
   
   public double energy(int x, int y)
   {
       double result = 1000;
       
       if ((x-1 >= 0 && x+1 < mPicture.width()) &&
           (y-1 >= 0 && y+1 < mPicture.height()))
       {
           double energy_pixel = 0;
           Color right_color = mPicture.get(x+1, y);
           Color left_color = mPicture.get(x-1, y);
           double xdelta_blue = 
                Math.pow(
                    Math.abs(right_color.getBlue() - left_color.getBlue()), 2);
           double xdelta_green = 
                Math.pow(
                    Math.abs(right_color.getGreen()- left_color.getGreen()), 2);
           double xdelta_red = 
                Math.pow(
                    Math.abs(right_color.getRed()- left_color.getRed()), 2);
           energy_pixel += xdelta_blue + xdelta_green + xdelta_red;
           
           Color up_color = mPicture.get(x, y-1);
           Color down_color = mPicture.get(x, y+1);
           double ydelta_blue = 
                Math.pow(
                   Math.abs(up_color.getBlue() - down_color.getBlue()), 2);
           double ydelta_green = 
                Math.pow(
                   Math.abs(up_color.getGreen()- down_color.getGreen()), 2);
           double ydelta_red = 
                Math.pow(
                   Math.abs(up_color.getRed()- down_color.getRed()), 2);
           energy_pixel += ydelta_blue + ydelta_green + ydelta_red;
           
           result = Math.sqrt(energy_pixel);
       }
       return result;
   }
   
   public int[] findHorizontalSeam()
   {
       EdgeWeightedDigraph graph;
       int size_x = mPicture.width(); 
       int size_y = mPicture.height();
       graph = new EdgeWeightedDigraph(size_x*size_y+1);
       for (int y = 0; y < size_y; ++y)
       {
            for (int x = 0; x < size_x; ++x)
            {
                if (x + 1 < size_x)
                {
                    graph.addEdge(
                        new DirectedEdge(x * size_y + y, 
                                        (x + 1) * size_y + y, mEnergy[x][y]));
                    if (y - 1 >= 0)
                        graph.addEdge(
                            new DirectedEdge(x * size_y + y, 
                                            (x + 1) * size_y + (y - 1), mEnergy[x][y]));
                    if (y + 1 < size_y)
                        graph.addEdge(
                            new DirectedEdge(x * size_y + y, 
                                            (x + 1) * size_y + (y + 1), mEnergy[x][y]));
                }
                graph.addEdge(
                        new DirectedEdge((size_x - 1) * size_y + y, 
                                          size_x * size_y, 0));
            }
       }
       
       double min_distance = -1;
       Iterator<DirectedEdge> min_path = null;
       for (int y = 0; y < size_y; ++y)
       {
           DijkstraSP shortest_path;
           shortest_path = new DijkstraSP(graph, y);
           double temp_distance = shortest_path.distTo(size_x*size_y);
           if (min_distance == -1 || 
               temp_distance < min_distance)
           {
               min_distance = temp_distance;
               min_path = shortest_path.pathTo(size_x*size_y).iterator();
           }
       }
       
       int[] horizontalSeam = new int[size_x];
       int i = 0;
       do
       {
           horizontalSeam[i++] = min_path.next().from() % size_y;
       } while(min_path.hasNext() && i < size_x);
       if (size_x > 1)
       {
            horizontalSeam[0] = horizontalSeam[1];
            horizontalSeam[size_x-1] = horizontalSeam[size_x-2];    
       }
       return horizontalSeam;
   }
   
   public int[] findVerticalSeam()
   {
       EdgeWeightedDigraph graph;
       int size_x = mPicture.width(); 
       int size_y = mPicture.height();
       graph = new EdgeWeightedDigraph(size_x*size_y+1);
       for (int x = 0; x < size_x; ++x)
       {
            for (int y = 0; y < size_y; ++y)
            {
                if (y + 1 < size_y)
                {
                    graph.addEdge(
                        new DirectedEdge(y * size_x + x, 
                                        (y + 1) * size_x + x, mEnergy[x][y]));
                    if (x - 1 >= 0)
                        graph.addEdge(
                            new DirectedEdge(y * size_x + x, 
                                            (y + 1) * size_x + (x - 1), mEnergy[x][y]));
                    if (x + 1 < size_x)
                        graph.addEdge(
                            new DirectedEdge(y * size_x + x, 
                                            (y + 1) * size_x + (x + 1), mEnergy[x][y]));
                }
                graph.addEdge(
                        new DirectedEdge((size_y - 1) * size_x + x, 
                                          size_y * size_x, 0));
            }
       }
       
       double min_distance = -1;
       Iterator<DirectedEdge> min_path = null;
       for (int x = 0; x < size_x; ++x)
       {
           DijkstraSP shortest_path;
           shortest_path = new DijkstraSP(graph, x);
           double temp_distance = shortest_path.distTo(size_x*size_y);
           if (min_distance == -1 || 
               temp_distance < min_distance)
           {
               min_distance = temp_distance;
               min_path = shortest_path.pathTo(size_x*size_y).iterator();
           }
       }
       
       int[] verticalSeam = new int[size_y];
       int i = 0;
       do
       {
           verticalSeam[i++] = min_path.next().from() % size_x;
       } while(min_path.hasNext() && i < size_y);
       if (size_y > 1)
       {
            verticalSeam[0] = verticalSeam[1];
            verticalSeam[size_y-1] = verticalSeam[size_y-2];    
       }
       return verticalSeam;
   }
   
   public void removeHorizontalSeam(int[] seam)
   {
       int size_x = mPicture.width();
       int size_y = mPicture.height();
       Picture temp;
       temp = new Picture(size_x, size_y-1);
       for (int x = 0; x < size_x; ++x)
       {       
            for (int y = 0; y < size_y; ++y)
            {
                if (seam[x] != y)
                    temp.set(x, (y > seam[x])? y-1 : y, mPicture.get(x, y));
            }
       }
       mPicture = temp;
   }
   
   public void removeVerticalSeam(int[] seam)
   {
       int size_x = mPicture.width();
       int size_y = mPicture.height();
       Picture temp;
       temp = new Picture(size_x-1, size_y);
       for (int y = 0; y < size_y; ++y)
       {       
            for (int x = 0; x < size_x; ++x)
            {
                if (seam[y] != x)
                    temp.set((x > seam[y])? x-1 : x, y, mPicture.get(x, y));
            }
       }
       mPicture = temp;
   }
}
